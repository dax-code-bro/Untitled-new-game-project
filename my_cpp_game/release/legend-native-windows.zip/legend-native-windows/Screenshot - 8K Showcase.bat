@echo off
cd /d "%~dp0"
echo Rendering 7680x4320 -- this takes a few seconds on a real GPU.
my_cpp_game.exe --width 7680 --height 4320 --quality cinematic --texture-res 4096 --frames 16 --screenshot showcase-8k.png
pause
