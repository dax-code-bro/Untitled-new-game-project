@echo off
cd /d "%~dp0"
my_cpp_game.exe --fullscreen --play --scene scenes\coastline.lescene --texture-res 2048
if errorlevel 1 pause
