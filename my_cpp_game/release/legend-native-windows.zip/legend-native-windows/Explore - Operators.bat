@echo off
cd /d "%~dp0"
my_cpp_game.exe --fullscreen --scene scenes\roster.lescene --texture-res 4096 --eye 0,1.35,6.5 --target 0,1.0,0
if errorlevel 1 pause
