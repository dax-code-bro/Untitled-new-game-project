@echo off
cd /d "%~dp0"
my_cpp_game.exe --width 1600 --height 900
if errorlevel 1 pause
