@echo off
cd /d "%~dp0"
my_cpp_game.exe --fullscreen
if errorlevel 1 pause
