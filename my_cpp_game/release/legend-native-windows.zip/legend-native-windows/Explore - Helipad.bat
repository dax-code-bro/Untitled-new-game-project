@echo off
cd /d "%~dp0"
my_cpp_game.exe --fullscreen --scene scenes\helipad.lescene --texture-res 4096
if errorlevel 1 pause
